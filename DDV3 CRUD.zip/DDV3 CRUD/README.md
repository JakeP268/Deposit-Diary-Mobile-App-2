# Deposit Diary Version 3

In the third version I have implemented crud functionality,
along wit realtime db allowing updates and deletions of 
deposits which the user can do through the 
entries fragment.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 
