# Deposit Diary Version 6

Firebase Auth UI along with static markers for public toilet locations
and overhaul on tweaking layout placements, colours in certain 
layouts etc.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 

