# Deposit Diary Version 2

In the second Version of the application, Firebase has been implemented
with a email login for individual users accounts, along with a login 
startup activity to allow this and sign out feature.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 
