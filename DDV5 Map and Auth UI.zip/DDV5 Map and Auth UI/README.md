# Deposit Diary Version 5

Adding Google Maps API for current user location, 
Firebase UI Auth and adding more 
to layouts creation.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 

