# Deposit Diary Version 1

In this first version of the application is a navigation drawer 
featuring the basic setup of fragments for content i will add 
into later versions. ADd and List functionalities are put
to use with the deposit and entries fragments
along the recyclerview.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 
