# Deposit Diary Version 4

Adding Google Auth and Storage, along 
with tweaking layouts.

Repo for the Deposit Diary created and developed with 
the use of Android Studio, Kotlin and Firebase. 

